
import { useEffect, useRef, useState } from "react"
import { createChart, ColorType, IChartApi, ISeriesApi } from "lightweight-charts"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface StockChartProps {
  data: {
    time: string
    open: number
    high: number
    low: number
    close: number
  }[]
}

export function StockChart({ data }: StockChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const maSeriesRef = useRef<ISeriesApi<"Line"> | null>(null)
  const rsiSeriesRef = useRef<ISeriesApi<"Line"> | null>(null)
  const [showMA, setShowMA] = useState(false)
  const [showRSI, setShowRSI] = useState(false)

  const calculateMA = (period: number) => {
    return data.map((item, index) => {
      if (index < period - 1) return null
      const sum = data.slice(index - period + 1, index + 1)
        .reduce((acc, curr) => acc + curr.close, 0)
      return {
        time: item.time.split("T")[0],
        value: sum / period
      }
    }).filter((item): item is { time: string; value: number } => item !== null)
  }

  const calculateRSI = (period: number = 14) => {
    let gains: number[] = []
    let losses: number[] = []
    let rsi: { time: string; value: number }[] = []

    data.forEach((item, index) => {
      if (index === 0) return

      const difference = item.close - data[index - 1].close
      gains.push(Math.max(0, difference))
      losses.push(Math.max(0, -difference))

      if (index >= period) {
        const avgGain = gains.slice(-period).reduce((sum, gain) => sum + gain, 0) / period
        const avgLoss = losses.slice(-period).reduce((sum, loss) => sum + loss, 0) / period
        const rs = avgGain / avgLoss
        const rsiValue = 100 - (100 / (1 + rs))

        rsi.push({
          time: item.time.split("T")[0],
          value: rsiValue
        })
      }
    })

    return rsi
  }

  useEffect(() => {
    if (!chartContainerRef.current) return

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#999",
      },
      grid: {
        vertLines: { color: "#2e2e2e" },
        horzLines: { color: "#2e2e2e" },
      },
      width: chartContainerRef.current.clientWidth,
      height: 400,
    })

    const candlestickSeries = chart.addCandlestickSeries({
      upColor: "#26a69a",
      downColor: "#ef5350",
      borderVisible: false,
      wickUpColor: "#26a69a",
      wickDownColor: "#ef5350",
    })

    const maSeries = chart.addLineSeries({
      color: "#2962FF",
      lineWidth: 2,
      title: "MA(20)",
      visible: showMA,
    })

    const rsiSeries = chart.addLineSeries({
      color: "#FF6B6B",
      lineWidth: 2,
      title: "RSI(14)",
      visible: showRSI,
      priceFormat: {
        type: "price",
        precision: 2,
        minMove: 0.01,
      },
    })

    candlestickSeries.setData(
      data.map((item) => ({
        ...item,
        time: item.time.split("T")[0],
      }))
    )

    maSeries.setData(calculateMA(20))
    rsiSeries.setData(calculateRSI(14))

    maSeriesRef.current = maSeries
    rsiSeriesRef.current = rsiSeries
    chartRef.current = chart

    chart.timeScale().fitContent()

    const handleResize = () => {
      if (chartContainerRef.current) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
        })
      }
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
      chart.remove()
    }
  }, [data, showMA, showRSI])

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowMA(!showMA)}
          className="flex items-center gap-2"
        >
          {showMA ? <Eye size={16} /> : <EyeOff size={16} />}
          MA(20)
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowRSI(!showRSI)}
          className="flex items-center gap-2"
        >
          {showRSI ? <Eye size={16} /> : <EyeOff size={16} />}
          RSI(14)
        </Button>
      </div>
      <div ref={chartContainerRef} />
    </div>
  )
}
