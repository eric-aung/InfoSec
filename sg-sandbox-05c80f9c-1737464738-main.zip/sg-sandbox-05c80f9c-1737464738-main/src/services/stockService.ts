
const ALPHA_VANTAGE_API_KEY = "G9O9O7MWKNYDZRBG"

export interface StockSearchResult {
  symbol: string
  name: string
  type: string
  region: string
}

export interface CandleData {
  time: string
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export const stockService = {
  async searchStocks(query: string): Promise<StockSearchResult[]> {
    if (!query) return []
    const response = await fetch(
      `https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords=${query}&apikey=${ALPHA_VANTAGE_API_KEY}`
    )
    const data = await response.json()
    return data.bestMatches?.map((match: any) => ({
      symbol: match["1. symbol"],
      name: match["2. name"],
      type: match["3. type"],
      region: match["4. region"],
    })) || []
  },

  async getStockCandles(symbol: string): Promise<CandleData[]> {
    const response = await fetch(
      `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${ALPHA_VANTAGE_API_KEY}&outputsize=compact`
    )
    const data = await response.json()
    const timeSeriesData = data["Time Series (Daily)"]
    
    if (!timeSeriesData) return []
    
    return Object.entries(timeSeriesData).map(([date, values]: [string, any]) => ({
      time: date,
      open: parseFloat(values["1. open"]),
      high: parseFloat(values["2. high"]),
      low: parseFloat(values["3. low"]),
      close: parseFloat(values["4. close"]),
      volume: parseFloat(values["5. volume"]),
    })).reverse()
  }
}
