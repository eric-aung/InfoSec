
import { Card } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function DocumentationPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-4xl font-bold mb-8">StockVision Documentation</h1>
      
      <ScrollArea className="h-[800px] rounded-md border p-4">
        <Accordion type="single" collapsible className="space-y-4">
          <AccordionItem value="architecture">
            <AccordionTrigger className="text-xl font-semibold">System Architecture</AccordionTrigger>
            <AccordionContent className="space-y-4 text-muted-foreground">
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Project Structure</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li><code>src/components</code>: Reusable UI components</li>
                  <li><code>src/pages</code>: Application routes and pages</li>
                  <li><code>src/services</code>: API integration and data services</li>
                  <li><code>src/contexts</code>: Global state management</li>
                </ul>
              </Card>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="authentication">
            <AccordionTrigger className="text-xl font-semibold">Authentication System</AccordionTrigger>
            <AccordionContent className="space-y-4 text-muted-foreground">
              <Card className="p-4">
                <h3 className="font-semibold mb-2">How Authentication Works</h3>
                <p>The authentication system uses a built-in admin account:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Email: admin@stockvision.com</li>
                  <li>Password: admin123</li>
                </ul>
                <h4 className="font-semibold mt-4 mb-2">Customization Points</h4>
                <p>To modify authentication:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Edit <code>src/contexts/AuthContext.tsx</code> to add new authentication methods</li>
                  <li>Modify <code>src/components/auth/AuthForm.tsx</code> for UI changes</li>
                </ul>
              </Card>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="stock-chart">
            <AccordionTrigger className="text-xl font-semibold">Stock Chart System</AccordionTrigger>
            <AccordionContent className="space-y-4 text-muted-foreground">
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Chart Components</h3>
                <p>The stock chart system uses lightweight-charts library with custom indicators:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Japanese Candlestick Chart</li>
                  <li>Moving Average (MA) Indicator</li>
                  <li>Relative Strength Index (RSI)</li>
                </ul>
                <h4 className="font-semibold mt-4 mb-2">Adding New Indicators</h4>
                <p>To add new technical indicators:</p>
                <ol className="list-decimal pl-6 space-y-2">
                  <li>Open <code>src/components/stocks/StockChart.tsx</code></li>
                  <li>Add new calculation function (like calculateMA)</li>
                  <li>Create new series using chart.addLineSeries()</li>
                  <li>Add visibility toggle button</li>
                </ol>
              </Card>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="api-integration">
            <AccordionTrigger className="text-xl font-semibold">API Integration</AccordionTrigger>
            <AccordionContent className="space-y-4 text-muted-foreground">
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Alpha Vantage API</h3>
                <p>The application uses Alpha Vantage for stock data:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>API Key: Located in <code>src/services/stockService.ts</code></li>
                  <li>Current endpoints used:</li>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>SYMBOL_SEARCH: Stock symbol search</li>
                    <li>TIME_SERIES_DAILY: Daily price data</li>
                  </ul>
                </ul>
                <h4 className="font-semibold mt-4 mb-2">Adding New API Features</h4>
                <p>To add new API functionality:</p>
                <ol className="list-decimal pl-6 space-y-2">
                  <li>Add new methods to stockService</li>
                  <li>Create corresponding interfaces for response types</li>
                  <li>Implement error handling</li>
                </ol>
              </Card>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="customization">
            <AccordionTrigger className="text-xl font-semibold">Customization Guide</AccordionTrigger>
            <AccordionContent className="space-y-4 text-muted-foreground">
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Adding New Features</h3>
                <p>Common customization points:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>New Chart Indicators:
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Add calculation logic in StockChart.tsx</li>
                      <li>Create new visibility toggle</li>
                      <li>Add new line series to the chart</li>
                    </ul>
                  </li>
                  <li>New Stock Data Features:
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Add new API methods in stockService.ts</li>
                      <li>Create new UI components in dashboard/index.tsx</li>
                    </ul>
                  </li>
                  <li>Authentication Changes:
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Modify AuthContext.tsx for new auth methods</li>
                      <li>Update AuthForm.tsx for UI changes</li>
                    </ul>
                  </li>
                </ul>
              </Card>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </ScrollArea>
    </div>
  )
}
