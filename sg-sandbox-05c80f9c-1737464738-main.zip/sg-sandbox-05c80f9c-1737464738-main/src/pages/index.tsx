
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import Head from "next/head"

export default function Home() {
  return (
    <>
      <Head>
        <title>StockVision - Real-Time Stock Analysis</title>
        <meta name="description" content="Advanced stock analysis with Japanese candlestick charts" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center space-y-6">
            <h1 className="text-5xl font-bold tracking-tight">
              Advanced Stock Analysis Platform
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Track real-time stock prices, analyze trends with Japanese candlestick charts, and make informed decisions.
            </p>
            <div className="flex gap-4 justify-center mt-8">
              <Link href="/auth/login">
                <Button size="lg">
                  Login
                </Button>
              </Link>
              <Link href="/auth/register">
                <Button size="lg" variant="outline">
                  Register
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-16">
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-2">Real-Time Data</h3>
              <p className="text-muted-foreground">
                Get instant access to live stock prices and market data
              </p>
            </Card>
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-2">Advanced Charts</h3>
              <p className="text-muted-foreground">
                Analyze trends with Japanese candlestick patterns
              </p>
            </Card>
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-2">Smart Search</h3>
              <p className="text-muted-foreground">
                Find stocks quickly with intelligent autocomplete
              </p>
            </Card>
          </div>
        </div>
      </main>
    </>
  )
}
