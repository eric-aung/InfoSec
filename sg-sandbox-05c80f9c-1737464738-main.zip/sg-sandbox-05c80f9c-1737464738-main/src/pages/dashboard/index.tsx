
import { DashboardLayout } from "@/components/layout/DashboardLayout"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"
import { StockChart } from "@/components/stocks/StockChart"
import { stockService } from "@/services/stockService"
import type { StockSearchResult, CandleData } from "@/services/stockService"

export default function DashboardPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<StockSearchResult[]>([])
  const [selectedStock, setSelectedStock] = useState<string | null>(null)
  const [candleData, setCandleData] = useState<CandleData[]>([])
  const [loading, setLoading] = useState(false)

  const commonTickers = [
    { symbol: "SPY", name: "SPDR S&P 500 ETF Trust" },
    { symbol: "GLD", name: "SPDR Gold Trust" },
    { symbol: "QQQ", name: "Invesco QQQ Trust" },
  ]

  useEffect(() => {
    const searchStocks = async () => {
      if (searchQuery.length < 2) {
        setSearchResults([])
        return
      }
      const results = await stockService.searchStocks(searchQuery)
      setSearchResults(results)
    }

    const timeoutId = setTimeout(searchStocks, 500)
    return () => clearTimeout(timeoutId)
  }, [searchQuery])

  const loadStockData = async (symbol: string) => {
    setLoading(true)
    try {
      const data = await stockService.getStockCandles(symbol)
      setCandleData(data)
      setSelectedStock(symbol)
    } catch (error) {
      console.error("Error loading stock data:", error)
    }
    setLoading(false)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="relative">
          <Input
            type="search"
            placeholder="Search stocks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-md"
          />
          {searchResults.length > 0 && (
            <div className="absolute z-10 w-full max-w-md mt-1 bg-background border rounded-md shadow-lg">
              {searchResults.map((result) => (
                <Button
                  key={result.symbol}
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => {
                    loadStockData(result.symbol)
                    setSearchQuery("")
                    setSearchResults([])
                  }}
                >
                  <div>
                    <div className="font-bold">{result.symbol}</div>
                    <div className="text-sm text-muted-foreground">{result.name}</div>
                  </div>
                </Button>
              ))}
            </div>
          )}
        </div>

        {selectedStock && candleData.length > 0 && (
          <Card className="p-6">
            <h2 className="text-xl font-bold mb-4">{selectedStock}</h2>
            <StockChart data={candleData} />
          </Card>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {commonTickers.map((ticker) => (
            <Card 
              key={ticker.symbol} 
              className="p-4 cursor-pointer hover:bg-accent"
              onClick={() => loadStockData(ticker.symbol)}
            >
              <h3 className="font-bold">{ticker.symbol}</h3>
              <p className="text-sm text-muted-foreground">{ticker.name}</p>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  )
}
